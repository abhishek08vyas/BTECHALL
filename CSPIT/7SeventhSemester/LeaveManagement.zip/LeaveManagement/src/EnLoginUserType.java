public enum EnLoginUserType {
	/* Login as a admin */
	Admin,

	/* Login as a RA user */
	RA,

	/* Login as a Normal user */
	Employee
}
